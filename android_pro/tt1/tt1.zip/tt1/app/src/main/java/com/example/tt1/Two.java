package com.example.tt1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class Two extends AppCompatActivity {
    public PreferencesHelperImp preferencesHelperImp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);
        TextView textView=(TextView) findViewById(R.id.test);
//        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("sharedPreferences", MODE_PRIVATE);
//        String email=sharedPreferences.getString("data","");

        preferencesHelperImp = new PreferencesHelperImp(getApplicationContext());
        String email =preferencesHelperImp.getStringData();
        textView.setText(email);
        Log.d("Mainactivity", "onClick: " + email);
    }
}
